# Pokémon Classifier

This project is a machine learning web application that predicts Pokémon classifications based on user input. It utilizes a trained machine learning model to classify Pokémon and provide results through a user-friendly interface.

## Features

- User-friendly interface for Pokémon classification
- Machine learning model for accurate predictions
- Django framework for robust web application development

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd pokemon-classifier
   ```
3. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

To run the application, use the following command:
```
python manage.py runserver
```
Then, open your web browser and go to `http://127.0.0.1:8000/`.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or features.

## License

This project is licensed under the MIT License.